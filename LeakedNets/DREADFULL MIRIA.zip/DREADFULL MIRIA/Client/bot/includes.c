#include "headers/includes.h"

ipv4_t LOCAL_ADDR;