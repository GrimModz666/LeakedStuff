#pragma once

#define HTTP_SERVER "84.21.172.171"
#define HTTP_PORT 80

#define TFTP_SERVER "84.21.172.171"
