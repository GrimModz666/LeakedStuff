package main

import (
	"bufio"
	"fmt"
	"github.com/denisbrodbeck/machineid"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"runtime"
	"strings"
)

func checkError(err error, msg string) {
	if err != nil {
		log.Printf(LogError + msg)
		os.Exit(1)
	}
}

func getHWID() (string, error) {
	if runtime.GOOS == "windows" {
		return "", fmt.Errorf("windows HWID method not implemented")
	} else {
		hwID, err := machineid.ID()
		if err != nil {
			return "", err
		}
		return hwID, nil
	}
}

func authenticate() {
	hwID, err := getHWID()
	checkError(err, "Machine ID Error")

	file, err := os.Open(".auth")
	checkError(err, "File Open Error")
	defer file.Close()

	scanner := bufio.NewScanner(file)
	authData := ""
	if scanner.Scan() {
		authData = scanner.Text()
	}

	err = scanner.Err()
	checkError(err, "Scanner Error")

	resp, err := http.Get("https://pastebin.com/raw/7HaWfGnw")
	checkError(err, "HTTP Request Error")
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	checkError(err, "Read Body Error")

	serverData := string(body)

	if strings.Contains(authData, hwID) && strings.Contains(serverData, hwID) {
		fmt.Println("\u001B[0m[\u001B[91mHinata\u001B[0m/\u001B[91mauth\u001B[0m] Authentication successful")
	} else {
		fmt.Printf("\u001B[0m[\u001B[91mHinata\u001B[0m/\u001B[91mauth\u001B[0m] Invalid HWID. Send kent your HWID: %s\r\n", hwID)
		os.Exit(1)
	}
}
