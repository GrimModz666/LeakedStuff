#pragma once

#define HTTP_SERVER "213.219.38.167"
#define HTTP_PORT 80

#define TFTP_SERVER "213.219.38.167"


/*
nigger code fr
*/
