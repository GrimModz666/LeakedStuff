import colorama
import time
import os
import random
from colorama import Fore, init

W = Fore.RESET
R = Fore.LIGHTRED_EX
C = Fore.LIGHTCYAN_EX
G = Fore.LIGHTGREEN_EX
init()
chara = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 
num = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"

os.system("mode con lines=22 cols=58")

def display():
    print(f"""
   {C}██████{W}╗{C}██{W}╗   {C}██{W}╗{C}██████{W}╗ {C}███████{W}╗{C}██████{W}╗ {C}██{W}╗ {C}█████{W}╗ 
  {C}██{W}╔════╝╚{C}██{W}╗ {C}██{W}╔╝{C}██{W}╔══{C}██{W}╗{C}██{W}╔════╝{C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}╗
  {C}██{W}║      ╚{C}████{W}╔╝ {C}██████{W}╔╝{C}█████{W}╗  {C}██████{W}╔╝{C}██{W}║{C}███████{W}║
  {C}██{W}║       ╚{C}██{W}╔╝  {C}██{W}╔══{C}██{W}╗{C}██{W}╔══╝  {C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}║
  {W}╚{C}██████{W}╗   {C}██{W}║   {C}██████{W}╔╝{C}███████{W}╗{C}██{W}║  {C}██{W}║{C}██{W}║{C}██{W}║  {C}██{W}║
   ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝""")

def main():
    try:
        character = input(f" How many characters would you like in your password:{C} ")
        
        time.sleep(2)
        number = input(f" {W}Would you like numbers in your password {W}({G}y{W}/{R}n{W}):{C} ")
        print(f"{W}") 
        if number == ("y"):
            password = ''.join(random.choice(num) for _ in range(int(character)))
            print(f"{W}-" * 58)
            print(f" Password created:{C} {password}{W}")
            time.sleep(1)
            print(f" Amount of characters :{C} {character}{W}")
            time.sleep(1)
            print(f" Numbers: {G}Enabled{W}")
            time.sleep(1)
            print(f" Saved to {C}passes.txt{W} you can find this in the txt folder")
            print(f"{W}-" * 55)
            time.sleep(1)
            with open ("tools/passes.txt", "a") as file:
                print(f"\nPassword created: {password}", file=file) 
            question()       
        elif number ==  ("n"):
            password = ''.join(random.choice(chara) for _ in range(int(character)))
            print(f"{W}-" * 58)
            print(f" Password created:{C} {password}{W}")
            time.sleep(1)
            print(f" Amount of characters :{C} {character}{W}")
            time.sleep(1)
            print(f" Numbers: {R}Disabed{W}")
            time.sleep(1)
            print(f" Saved to {C}passes.txt{W} you can find this in the {C}txt{W} folder")
            time.sleep(1)
            print(f"{W}-" * 58)
            time.sleep(1)
            with open ("tools/passes.txt", "a") as file:
                print(f"\nPassword created: {password}", file=file) 
            question()      
        else:
            print(" Invalid Choice Please Try Again...")
            time.sleep(2)
            os.system("cls")
            display()
            main()
    except KeyboardInterrupt:
        pass
    except ValueError:
        print(f" {W}Please use numbers and not letters!")
        time.sleep(2)
        os.system("cls")
        display()
        main()


def question():
    gen = input(f"\n {W}Do you want to generate a new password{W}({G}y{W}/{R}n{W}):{C} ")
    if gen == "y":
        time.sleep(1)
        os.system("cls")
        display()
        main() 
    elif gen == "n":
        print(" closing tool!")
        time.sleep(1)
        exit
    else:
        print(" Invalid command try again...")
        time.sleep(2)
        question()

        
if __name__ == "__main__":
    display()
    main()
