import socket
import os
from colorama import Fore, init

W = Fore.RESET
C = Fore.LIGHTCYAN_EX
L = Fore.LIGHTGREEN_EX

init()

def print_banner():
    print(f"""    
 {C}██████{W}╗{C}██{W}╗   {C}██{W}╗{C}██████{W}╗ {C}███████{W}╗{C}██████{W}╗ {C}██{W}╗ {C}█████{W}╗ 
{C}██{W}╔════╝╚{C}██{W}╗ {C}██{W}╔╝{C}██{W}╔══{C}██{W}╗{C}██{W}╔════╝{C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}╗
{C}██{W}║      ╚{C}████{W}╔╝ {C}██████{W}╔╝{C}█████{W}╗  {C}██████{W}╔╝{C}██{W}║{C}███████{W}║
{C}██{W}║       ╚{C}██{W}╔╝  {C}██{W}╔══{C}██{W}╗{C}██{W}╔══╝  {C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}║
{W}╚{C}██████{W}╗   {C}██{W}║   {C}██████{W}╔╝{C}███████{W}╗{C}██{W}║  {C}██{W}║{C}██{W}║{C}██{W}║  {C}██{W}║
 ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝ """)

def lookup_domain():
    domain_name = input("Enter the domain name: ")
    try:
        ip_address = socket.gethostbyname(domain_name)
        print(f"The IP address of {domain_name} is {ip_address}")
    except socket.gaierror:
        print("Please enter a valid domain!")
        os.system("Timeout 3")
        os.system("cls")
        print_banner()
        lookup_domain()

def main():
    while True:
        print_banner()
        lookup_domain()
        choice = input("Type 'restart' if you would like to lookup another domain! \nOr 'close' if you want to close the tool! \n-> ")
        print("succesful")
        if choice.lower() == 'close':
            break
        elif choice.lower() == 'restart':
            if os.name == 'nt':
                os.system("cls")
            else:
                os.system("clear")
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

