import os
import colorama
import urllib.error
from pytubefix import YouTube, Channel, Playlist
from pytube.exceptions import VideoUnavailable
from colorama import Fore, init

c = Fore.LIGHTCYAN_EX
w = Fore.RESET
init()
os.system('title Silk YT Tool')
os.system('mode 100,25')


def display():
    print(f'''
  {c}███████{w}╗{c}██{w}╗{c}██{w}╗     {c}██{w}╗  {c}██{w}╗    
  {c}██{w}╔════╝{c}██{w}║{c}██{w}║     {c}██{w}║ {c}██{w}╔╝    
  {c}███████{w}╗{c}██{w}║{c}██{w}║     {c}█████{w}╔╝      
  {w}╚════{c}██{w}║{c}██{w}║{c}██{w}║     {c}██{w}╔═{c}██{w}╗     
  {c}███████{w}║{c}██{w}║{c}███████{w}╗{c}██{w}║  {c}██{w}╗    
  {w}╚══════╝╚═╝╚══════╝╚═╝  ╚═╝    
    ''')

def thumbnail():
    try:
        q = input(f'  Please enter the video URL: {c}')
        yt = YouTube(q)
        print(f'{c}-{w}-' * 50)
        print(f'  Thumbnail URL: {c}{yt.thumbnail_url}')
        print(f'{c}-{w}-' * 50)
        question()
    except urllib.error.HTTPError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        thumbnail()
    except KeyError:
        print(f'{c}  ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        thumbnail()
    except VideoUnavailable:
         print(f'{yt.title}: unavailable, skipping.')

def playlist():
    try:
        q = input(f'  Enter the playlist link: {c}')
        p = Playlist(q)
        print(f'{c}-{w}-' * 50)
        print(f'  Playlist name: {c}{p.title}{w}')
        for video in p.videos:
            ys = video.streams.get_highest_resolution()
            ys.download(f'tools/playlists/{p.title}')
            print(f'  Succesfully downloaded: {c}{video.title}{w}')
        print(f'{c}-{w}-' * 50)
        question()
    except urllib.error.HTTPError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        playlist()
    except KeyError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        playlist()
    except VideoUnavailable:
         print(f'{p.title}: unavailable, skipping.')

def channel():
    try:
        q = input(f'  Please enter the channel URL: {c}')
        chan = Channel(f'{q}/videos')
        qt = input(f'  {w}Do you want \'{c}links\'{w} or \'{c}videos{w}\': {c}')
        if qt == 'videos':
            print(f'{c}-{w}-' * 50)
            print(f'  {c}WARNING{w}: This proccess will take longer based on how many videos the channel has!')
            for video in chan.videos:
                video.streams.first().download('tools/channels')
                print(f'  Successfully downloaded: {c}{video.title}{w}!')
            print(f'{c}-{w}-' * 50)
            question()
        elif qt == 'links':
            print(f'{c}-{w}-' * 50)
            for video in chan.videos:
                os.system('timeout 1 >nul')
                print(f'  Grabbed link: {c}{video.watch_url}{w}')
            print(f'{c}-{w}-' * 50)
            question()
        else:
            print(f'  {c}ERROR{w}: Invalid argument!')
            os.system('Timeout 2 >nul')
            os.system('cls')
            display()
            channel()
    except urllib.error.HTTPError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        channel()
    except KeyError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        channel()
    except VideoUnavailable:
        print(f'{chan.title}: unavailable, skipping.')
        
def choice():
        print(f'  {c}channel{w} - Allows you to do things with a users channel!\n  {c}song{w} - Download a song with the .mp3 extension!\n  {c}video{w} - Download a watchable video!\n  {c}thumbnail{w} - Get any youtube thumbnail!\n  {c}playlist{w} - Allows you to download any playlist')
        q = input(f'  Please type your command here: {c}')
        print(f'{w}')
        if q == 'song':
            os.system('cls')
            display()
            song()
        elif q == 'video':
            os.system('cls')
            display()
            video()
        elif q == 'channel':
            os.system('cls')
            display()
            channel()
        elif q == 'thumbnail':
            os.system('cls')
            display()
            thumbnail()
        elif q == 'playlist':
            os.system('cls')
            display()
            playlist()
        else:
            print(f'  {c}ERROR{w}: Invalid argument!')
            os.system('Timeout 2 >nul')
            os.system('cls')
            display()
            choice()
            
def video():
    try:
        url = input(f'  Enter the link for the video:{c} ')
        yt = YouTube(url)
        print(f'{c}-{w}-' * 50)
        print(f'{c}  WARNING{w}: This will take longer based on how long the video is!')
        print(f'  {w}Title of video: {c}{yt.title}{w}')
        print(f'  Channel owner: {c}{yt.channel_url}{w}')
        ys = yt.streams.get_highest_resolution()
        ys.download('tools/videos')
        print(f'  Successfully Downloaded in the \'{c}videos{w}\' folder!')
        print(f'{c}-{w}-' * 50)
        question()
    except urllib.error.HTTPError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        video()
    except KeyError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        video()
    except VideoUnavailable:
         print(f'{yt.title}: unavailable!')

def song():
    try:
        url = input(f'  Enter the link for the song: {c}') 
        yt = YouTube(url)
        print(f'{c}-{w}-' * 50)
        print(f'{c}  WARNING{w}: This will take longer based on how long the video is!')
        print(f'  {w}Title of video: {c}{yt.title}{w}')
        print(f'  {w}Channel owner: {c}{yt.channel_url}{w}')
        ys = yt.streams.get_audio_only()
        ys.download('tools/songs', mp3=True)
        print(f'  Successfully Downloaded in the your \'{c}songs{w}\' folder!')
        print(f'{c}-{w}-' * 50)
        question()
    except urllib.error.HTTPError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        song()
    except KeyError:
        print(f'  {c}ERROR{w}: Please make sure you are using a valid url!')
        os.system('timeout 2 >nul')
        os.system('cls')
        display()
        song()
    except VideoUnavailable:
        print(f'{yt.title}: unavailable, skipping.')

def question():
    q = input(f'  Do you want to restart the tool({c}y{w}/{c}n{w}): {c}')
    print(f'{w}')
    if q == 'y':
        os.system('cls')
        display()
        choice()
    elif q == 'n':
        os.system('timeout 2 >nul')
        print(f'  Closing tool, made by {c}silkovh!')
    else:
        print(f'  {c}ERROR{w}: Invalid argument!')
        os.system('Timeout 2 <nul')
        os.system('cls')
        display()
        choice()
    
if __name__ == '__main__':
    display()
    choice()
