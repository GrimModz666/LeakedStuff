#encoding: utf-8
import os
from faker import Faker
        
def main():
    fake = Faker(locale='en-US')
    print('''
██╗██████╗ ███████╗███╗   ██╗████████╗██╗████████╗██╗   ██╗     ██████╗ ███████╗███╗   ██╗    
██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝██║╚══██╔══╝╚██╗ ██╔╝    ██╔════╝ ██╔════╝████╗  ██║    
██║██║  ██║█████╗  ██╔██╗ ██║   ██║   ██║   ██║    ╚████╔╝     ██║  ███╗█████╗  ██╔██╗ ██║    
██║██║  ██║██╔══╝  ██║╚██╗██║   ██║   ██║   ██║     ╚██╔╝      ██║   ██║██╔══╝  ██║╚██╗██║    
██║██████╔╝███████╗██║ ╚████║   ██║   ██║   ██║      ██║       ╚██████╔╝███████╗██║ ╚████║    
╚═╝╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝   ╚═╝      ╚═╝        ╚═════╝ ╚══════╝╚═╝  ╚═══╝    

Please type what you would like to fake
---------------------------------------------------
name - This will generate a Fake name  
cc - This will generate fake cc info
address - This will generate a fake address
phone - This will generate a fake phone number 
company - This will generate a fake company  
identity - This will generate a full fake identity    
''')
    choice = input('please enter your choice here: ')
    print('-' * 52)
    if choice == 'name':
        gender = input('male or female?\nenter here: ')
        if gender == 'male':
            print(f'first name: {fake.first_name_male()}')
            print(f'last name: {fake.last_name_male()}')
            print('-' * 52)
            reset()
        elif gender == 'female':
            print(f'first name: {fake.first_name_female()}')
            print(f'last name: {fake.last_name_female()}')
            print('-' * 52)
            reset()
    elif choice == 'cc':
        print(f'name on card: {fake.first_name_female()} {fake.last_name_female()}')
        print(f'card number: {fake.credit_card_number()}')
        print(f'expiry date: {fake.credit_card_expire()}')
        print(f'security code: {fake.credit_card_security_code()}')
        print(f'billing address: {fake.address()}')
        print(f'card provider {fake.credit_card_provider()}')
        print('-' * 52)
        reset()
    elif choice == 'company':
        print(fake.company())
        print('-' * 52)
        reset()
    elif choice == 'address':
        print(fake.address())
        print('-' * 52)
        reset()
    elif choice == 'phone':
        print(f'phone number: {fake.phone_number()}')
        print('-' * 52)
        reset()
    elif choice == 'identity':
        gend = input('male or female: ')
        if gend == 'male':
            print(f'first name: {fake.first_name_male()}')
            print(f'last name: {fake.last_name_male()}')
            print(f'phone number: {fake.phone_number()}')
            print(f'current address: {fake.street_address()}')
            print(f'occupation: {fake.job()}')
            print(f'mothers name: {fake.first_name_female()}')
            print(f'fathers name: {fake.first_name_male()}')
            print(f'credit card number: {fake.credit_card_number()}')
            print(f'credit card expiry: {fake.credit_card_expire()}')
            print(f'credit card CVV: {fake.credit_card_security_code()}')
            print(f'credit card provider: Visa')
            print('-' * 52)
            reset()
        elif gend == 'female':
            print(f'first name: {fake.first_name_female()}')
            print(f'last name: {fake.last_name_female()}')
            print(f'phone number: {fake.phone_number()}')
            print(f'current address: {fake.street_address()}')
            print(f'occupation: {fake.job()}')
            print(f'mothers name: {fake.first_name_female()}')
            print(f'fathers name: {fake.first_name_male()}')
            print(f'credit card number: {fake.credit_card_number()}')
            print(f'credit card expiry: {fake.credit_card_expire()}')
            print(f'credit card CVV: {fake.credit_card_security_code()}')
            print(f'credit card provider: Visa')
            print(f'-' * 52)
            reset()
        else:
            print('invalid argument')
            os.system('timeout 3 >nul')
            main

def reset():
    restart = input('would you like to restart the tool (y/n): ')
    if restart == 'y':
        os.system('cls')
        main()
    else:
        print('closing now!')
        os.system('cls')
        exit()

if __name__ == '__main__':
    main()
