import os
import sys
from colorama import Fore, init

W = Fore.RESET
R = Fore.LIGHTRED_EX
C = Fore.LIGHTCYAN_EX
G = Fore.LIGHTGREEN_EX

init()

os.system("mode con lines=22 cols=58")

def caesar_cipher(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            base = ord('a') if char.islower() else ord('A')
            shifted_char = chr((ord(char) - base + shift) % 26 + base)
            result += shifted_char
        else:
            result += char
    return result

def display():
    print(f"""
   {C}██████{W}╗{C}██{W}╗   {C}██{W}╗{C}██████{W}╗ {C}███████{W}╗{C}██████{W}╗ {C}██{W}╗ {C}█████{W}╗ 
  {C}██{W}╔════╝╚{C}██{W}╗ {C}██{W}╔╝{C}██{W}╔══{C}██{W}╗{C}██{W}╔════╝{C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}╗
  {C}██{W}║      ╚{C}████{W}╔╝ {C}██████{W}╔╝{C}█████{W}╗  {C}██████{W}╔╝{C}██{W}║{C}███████{W}║
  {C}██{W}║       ╚{C}██{W}╔╝  {C}██{W}╔══{C}██{W}╗{C}██{W}╔══╝  {C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}║
  {W}╚{C}██████{W}╗   {C}██{W}║   {C}██████{W}╔╝{C}███████{W}╗{C}██{W}║  {C}██{W}║{C}██{W}║{C}██{W}║  {C}██{W}║
   ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝""")

def encrypt():
    try:
        print(f"  Please be aware that this program {R}can not{W} encrypt files \n  Or code it is just a simple {C}Ceasar Cypher{W}!")
        print("-" * 58)
        plaintext = input("  Enter your message: ")
        shift = int(input("  Enter how many letters do you want to shift: "))
        ciphertext = caesar_cipher(plaintext, +shift)
        print("-" * 58)
        print(f"  Cypher type: {C}Caesar Cyper {W}- {C}Encrypt {W}")
        os.system("timeout 1 >nul")
        print(f"  Orignal message: {C}{plaintext}{W}")
        os.system("timeout 1 >nul")
        print(f"  Encrypted message: {C}{ciphertext}{Fore.RESET}")
        os.system("timeout 1 >nul")
        print(f"  Character shift: {C}{shift}{W}")
        os.system("timeout 1 >nul")
        print(f"  Saved To: {C}cypher.txt{W}")
        print("-" * 58)
        question()
    except ValueError:
        print(f"  Invalid input. Please enter a valid shift value.{Fore.RESET}")
        os.system("timeout 2 >nul")
        os.system("cls")
        display()
        encrypt()

def decrypt():
    try:
        print("-" * 58)
        print(f"  Please be aware that this program {R}can not{W} encrypt files \n  Or code it is just a simple {C}Ceasar Cypher{W}!")
        plaintext = input("  Enter your message: ")
        shift = int(input("  Please enter the shift value of the encrypted text: "))
        ciphertext = caesar_cipher(plaintext, -shift)
        print("-" * 58)
        print(f"  Cypher type: {C}Caesar Cyper {W}- {C}Decrypt {W}")
        os.system("timeout 1 >nul")
        print(f"  Orignal message: {C}{plaintext}{W}")
        os.system("timeout 1 >nul")
        print(f"  Decrypted message: {C}{ciphertext}{Fore.RESET}")
        os.system("timeout 1 >nul")
        print(f"  Character shift: {C}{shift}{W}")
        os.system("timeout 1 >nul")
        print(f"  Saved To: {C}cypher.txt{W}")
        print("-" * 58)
        with open ("tools/cypher.txt", "a") as file:
                print(f"\nCypher created\n--------------\nOriginal message: {plaintext}\nEncrypted message: {ciphertext}\n Character shift: {shift}\n--------------", file=file)
        question()
    except ValueError:
        print(f"  Invalid input. Please enter a valid shift value.{Fore.RESET}")
        os.system("timeout 2 >nul")
        os.system("cls")
        display()
        decrypt()

def choice():
    print("-" * 58)
    print(f"  Please be aware that this program {R}can not{W} encrypt files \n  Or code it is just a simple {C}Ceasar Cypher{W}!")
    choic = input(f"  Would you like to {C}encrypt{W} or {C}decrypt{W} a message: ")
    if choic == "encrypt":
            os.system("cls")
            display()
            encrypt()
    elif choic == 'decrypt':
            os.system("cls")
            display()
            decrypt()
    else:
        print("-" * 58)
        print("Invalid argument make sure you typed correctly!")
        os.system("timeout 2 >nul")
        os.system("cls")
        display()
        choice()

def question():
    gen = input(f"\n {W}Do you want to restart the tool{W}({G}y{W}/{R}n{W}):{C} ")
    if gen == "y":
        os.system("timeout 1 >nul")
        os.system("cls")
        display()
        choice() 
    elif gen == "n":
        print(" closing tool!")
        os.system("timeout 1 >nul")
    else:
        print(" Invalid command try again...")
        os.system("timeout 1 >nul")
        question()
    



if __name__ == "__main__":
    display()
    choice()
