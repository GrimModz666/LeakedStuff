import os
import getpass
import time
import json
from colorama import Fore, init

W = Fore.RESET
C = Fore.LIGHTCYAN_EX
G = Fore.LIGHTGREEN_EX
R = Fore.RED
init()

password_manager = {}
os.system("mode con lines=22 cols=58")

def displaymenu():
    print(f"""
   {C}██████{W}╗{C}██{W}╗   {C}██{W}╗{C}██████{W}╗ {C}███████{W}╗{C}██████{W}╗ {C}██{W}╗ {C}█████{W}╗ 
  {C}██{W}╔════╝╚{C}██{W}╗ {C}██{W}╔╝{C}██{W}╔══{C}██{W}╗{C}██{W}╔════╝{C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}╗
  {C}██{W}║      ╚{C}████{W}╔╝ {C}██████{W}╔╝{C}█████{W}╗  {C}██████{W}╔╝{C}██{W}║{C}███████{W}║
  {C}██{W}║       ╚{C}██{W}╔╝  {C}██{W}╔══{C}██{W}╗{C}██{W}╔══╝  {C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}║
  {W}╚{C}██████{W}╗   {C}██{W}║   {C}██████{W}╔╝{C}███████{W}╗{C}██{W}║  {C}██{W}║{C}██{W}║{C}██{W}║  {C}██{W}║
   ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝""")

def caesar_cipher(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            base = ord('a') if char.islower() else ord('A')
            shifted_char = chr((ord(char) - base + shift) % 26 + base)
            result += shifted_char
        else:
            result += char
    return result

def create_account():
    username = input(f"  Enter your username: {C}")
    password = getpass.getpass(f"  {W}Enter your password: {C}")
    hashed_password = caesar_cipher(password, +25)
    password_manager[username] = hashed_password
    save_passwords(username)
    print(f'{W}-' * 58)
    print(f'Encoding your password be patient')
    time.sleep(2)    
    print(f'Encode: {G}success')
    time.sleep(2)
    print(f"{W}Successfully saved password for {C}{username}{W}")
    print(f'-' * 58)
    question()


def save_passwords(username):
    try:
        with open(f"tools/{username}.json", "w") as json_file:
            json.dump(password_manager, json_file, indent=2)
    except FileNotFoundError:
        print(f"  {R}Error: {W}Could not save passwords for {C}{username}\n  {G}Please contact the owner of the tool")
        time.sleep(5)
        exit()

def view():
        user = input(f"  Enter username of the password you want to recover: {C}")
        try:
            with open(f"tools/{user}.json", "r") as json_file:
                loaded_data = json.load(json_file)
                password_manager.update(loaded_data)
            if user in password_manager:
                decrypted_password = caesar_cipher(password_manager[user], -25)
                print(f'{W}-' * 58)
                print(f"  Recieved encoded password for {C}{user}")
                time.sleep(1)
                print(f"  {W}Attempting decode please be patient")
                time.sleep(2)
                print(f"  Decode: {G}Successful{W}")
                time.sleep(1)
                print(f"  {user}'s password: {C}{decrypted_password}")
                print(f'{W}-' * 58) 
                question()
            else:
                print(f"  {W}No password found for {C}{user}{W}")
                question()
        except FileNotFoundError:
            print(f"  {W}You have not saved {C}{user}{W}'s password before!")
            question()

def question():
    gen = input(f"\n  {W}Do you want to restart the tool ({C}y{W}/{C}n{W}): {C}")
    if gen == "y":
        time.sleep(1)
        os.system("cls")
        displaymenu()
        main()
    elif gen == "n":
        print(f"  {W}Closing tool!")
        save_passwords()
        time.sleep(1)
        exit()

def main():
    print(f"  Do you want to '{C}add{W}' or '{C}view{W}'\n")
    choice = input(f"  Enter your choice: {C}")
    if choice == 'add':
        os.system('cls')
        displaymenu()
        create_account()
    elif choice == 'view':
        os.system('cls')
        displaymenu()
        view()

if __name__ == "__main__":
    displaymenu()
    main()
