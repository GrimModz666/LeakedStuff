#encoding: utf-8
import os
import requests

loop = True

def main():
    global user, why, token
    print('''
███████╗██╗██╗     ██╗  ██╗    ██████╗ ███████╗██████╗  ██████╗ ██████╗ ████████╗███████╗██████╗
██╔════╝██║██║     ██║ ██╔╝    ██╔══██╗██╔════╝██╔══██╗██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝██╔══██╗
███████╗██║██║     █████╔╝     ██████╔╝█████╗  ██████╔╝██║   ██║██████╔╝   ██║   █████╗  ██████╔╝
╚════██║██║██║     ██╔═██╗     ██╔══██╗██╔══╝  ██╔═══╝ ██║   ██║██╔══██╗   ██║   ██╔══╝  ██╔══██╗
███████║██║███████╗██║  ██╗    ██║  ██║███████╗██║     ╚██████╔╝██║  ██║   ██║   ███████╗██║  ██║
╚══════╝╚═╝╚══════╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚══════╝╚═╝      ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
    ''')
    user = input('Please enter the username of the account you want to report: ')
    why = input('Please enter the reason you want on the reports: ')
    token = input('Please enter your instagram authoriaztion token: ')
    reportacc()

def reportacc():
    report = "https://api.instagram.com/v1/accounts/report"
    info = {
        'username': user,
        'reason': why,
        'access_token': token
    }
    while loop == True:
        response = requests.post(report, data=info)
        if response.status_code == 200:
            print(f"Reported {user} for {why}")
        elif response.status_code == 404:
            print('Invalid auth token please check again!')
            os.system('timeout 3 >nul')
            os.system('cls')
            main()
        else:
            print(f"Failed to report {user} {response.status_code}")

if __name__ == '__main__':
    main()
