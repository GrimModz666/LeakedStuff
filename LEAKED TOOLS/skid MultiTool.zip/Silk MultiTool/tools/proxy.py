import os
import requests
import json
import time 
import colorama
from colorama import Fore, init

W = Fore.RESET
R = Fore.LIGHTRED_EX
C = Fore.LIGHTCYAN_EX
L = Fore.LIGHTGREEN_EX
init()

os.system("mode con lines=22 cols=58")


def displaymenu():
    print(f"""
   {C}██████{W}╗{C}██{W}╗   {C}██{W}╗{C}██████{W}╗ {C}███████{W}╗{C}██████{W}╗ {C}██{W}╗ {C}█████{W}╗ 
  {C}██{W}╔════╝╚{C}██{W}╗ {C}██{W}╔╝{C}██{W}╔══{C}██{W}╗{C}██{W}╔════╝{C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}╗
  {C}██{W}║      ╚{C}████{W}╔╝ {C}██████{W}╔╝{C}█████{W}╗  {C}██████{W}╔╝{C}██{W}║{C}███████{W}║
  {C}██{W}║       ╚{C}██{W}╔╝  {C}██{W}╔══{C}██{W}╗{C}██{W}╔══╝  {C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}║
  {W}╚{C}██████{W}╗   {C}██{W}║   {C}██████{W}╔╝{C}███████{W}╗{C}██{W}║  {C}██{W}║{C}██{W}║{C}██{W}║  {C}██{W}║
   ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝""")

def main():
    try:
        arg = input("  Please enter an ip: ")
        answer = requests.get(f'http://proxycheck.io/v2/{arg}').json()
        print("-" * 58)
        print(f"  IP: {C}{arg}{W}")
        time.sleep(2)
        print(f"  proxy: {C}{answer[arg]['proxy']}{W}")
        time.sleep(2)
        print(f"  type: {C}{answer[arg]['type']}{W}")
        print("-" * 58)
        time.sleep(2)
        f = input(f"  Would you like to check another ip ({L}y{W}/{R}n{W})")
        if f == ("y"):
            os.system("cls")
            displaymenu()
            main()
        elif f == ("n"):
            exit()
    except KeyError:
        print("  Invalid ip try again...")
        os.system("timeout 1 >nul")
        os.system("cls")
        displaymenu()
        main()
    else:
        print("  Incorrect value, please try again...")
        time.sleep(2)
        os.system("cls")
        displaymenu()
        main()

if __name__ == "__main__":
    displaymenu()
    main()



