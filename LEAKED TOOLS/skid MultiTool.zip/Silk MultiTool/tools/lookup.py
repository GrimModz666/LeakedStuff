import requests
import colorama
import os
from colorama import Fore, init

W = Fore.RESET
C = Fore.LIGHTCYAN_EX
L = Fore.LIGHTGREEN_EX

init()

def print_banner():
    print(f"""
 {C}██████{W}╗{C}██{W}╗   {C}██{W}╗{C}██████{W}╗ {C}███████{W}╗{C}██████{W}╗ {C}██{W}╗ {C}█████{W}╗ 
{C}██{W}╔════╝╚{C}██{W}╗ {C}██{W}╔╝{C}██{W}╔══{C}██{W}╗{C}██{W}╔════╝{C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}╗
{C}██{W}║      ╚{C}████{W}╔╝ {C}██████{W}╔╝{C}█████{W}╗  {C}██████{W}╔╝{C}██{W}║{C}███████{W}║
{C}██{W}║       ╚{C}██{W}╔╝  {C}██{W}╔══{C}██{W}╗{C}██{W}╔══╝  {C}██{W}╔══{C}██{W}╗{C}██{W}║{C}██{W}╔══{C}██{W}║
{W}╚{C}██████{W}╗   {C}██{W}║   {C}██████{W}╔╝{C}███████{W}╗{C}██{W}║  {C}██{W}║{C}██{W}║{C}██{W}║  {C}██{W}║
 ╚═════╝   ╚═╝   ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝  
    """)

def lookup_ip():
    ip_address = input("Please enter the IP address you would like to look up -> ")
    response = requests.get(f'http://ip-api.com/json/{ip_address}?fields=status,continent,country,regionName,city,isp,org,mobile,proxy,message').json()
    print(f"Results for {ip_address}")
    print("_" * 70)
    print(f"Continent: {response['continent']}")
    print(f"Country: {response['country']}")
    print(f"Region: {response['regionName']}")
    print(f"City: {response['city']}")
    print(f"ISP: {response['isp']}")
    print(f"Organization: {response['org']}")
    print(f"Mobile: {response['mobile']}")
    print(f"Proxy: {response['proxy']}")
    print("_" * 70)

def main():
    while True:
        print_banner()
        lookup_ip()
        choice = input("Type 'restart' if you would like to lookup another IP! \nOr 'close' if you want to close the tool! \n-> ")
        if choice.lower() == 'close':
            break
        elif choice.lower() == 'restart':
            if os.name == 'nt':
                os.system("cls")
            else:
                os.system("clear")
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

1