import colorama
import sys
import os
import socket
import threading 
from colorama import init, Fore

W = Fore.RESET
B = Fore.RED
R = Fore.LIGHTCYAN_EX
G = Fore.LIGHTGREEN_EX
init()

os.system("mode con lines=25 cols=70")

def display_menu():
    print(f"""   
   {R}███████{W}╗{R}██{W}╗{R}██{W}╗     {R}██{W}╗  {R}██{W}╗    {R}███████{W}╗ {R}██████{W}╗ {R}█████{W}╗ {R}███{W}╗   {R}██{W}╗
   {R}██{W}╔════╝{R}██{W}║{R}██{W}║     {R}██{W}║ {R}██{W}╔╝    {R}██{W}╔════╝{R}██{W}╔════╝{R}██{W}╔══{R}██{W}╗{R}████{W}╗  {R}██{W}║
   {R}███████{W}╗{R}██{W}║{R}██{W}║     {R}█████{W}╔╝     {R}███████{W}╗{R}██{W}║     {R}███████{W}║{R}██{W}╔{R}██{W}╗ {R}██{W}║
   {W}╚════{R}██{W}║{R}██{W}║{R}██{W}║     {R}██{W}╔═{R}██{W}╗     ╚════{R}██{W}║{R}██{W}║     {R}██{W}╔══{R}██{W}║{R}██{W}║╚{R}██{W}╗{R}██{W}║
   {R}███████{W}║{R}██{W}║{R}███████{W}╗{R}██{W}║  {R}██{W}╗    {R}███████{W}║╚{R}██████{W}╗{R}██{W}║  {R}██{W}║{R}██{W}║ ╚{R}████{W}║
   ╚══════╝╚═╝╚══════╝╚═╝  ╚═╝    ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝
                                                                 """)

def scan():
    target = input(str(f"   [{R}-{W}] Please Enter An IP To Scan: {R}"))
    amount1 = int(input(f"   {W}[{R}-{W}] What Port You Would Like To Start scanning from: {R}"))
    amount = int(input(f"   {W}[{R}-{W}] What Port You Would Like To Scan Up To: {R}"))
            
    print(f"{W}_" * 70)
    print(" ")
    print(f"   Scanning IP: {R}" + target)
    print(f"   {W}Created By: {R}silkovh{W}")
    print("_" * 70)
    print("")
    print(f"   [{R}+{W}] Scan Initiated Please Be Patient While Ports Are Scanned!")
    print("_" * 70)
    print(f"{G}")
    try:
        
  
        for port in range(amount1, amount + 1):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                socket.setdefaulttimeout(0.1)
                print(f"{W}   [{R}+{W}] Checking Port:{R} {port}{W}")
                result = s.connect_ex((target, port))
                if result == 0:
                    print(" ")
                    with open("tools/ports.txt", "a") as file: 
                        print(f"{target}: Port found {port}!", file=file)
                    print(f"{W}_" * 70)
                    print(" ")
                    print(f"{W}   [{G}+{W}] Continuing In {R}5{W} Seconds!{W}\n")
                    print(f"{W}   [{G}+{W}] Success: Port {R}{port}{W} is open!\n")
                    os.system("timeout 5 >nul")
                
    except KeyboardInterrupt:   
        print(f"\n{W}   [{R}+{W}] Exiting!")
        os.system("timeout 5 >nul")
        exit
    except socket.error:
        print(f"\n{W}   [{R}+{W}] Please Enter A Valid IP Address!")
        os.system("timeout 5 >nul")
        main()
        

def main():
    while True:
        display_menu()
        scan()
        print(f"{W}_" * 70)
        print(" ")
        print(f"   [{R}+{W}] Successfully scanned for open ports!\n   [{R}+{W}] If there were no ports scanned\n   [{R}+{W}] Check ICMP is on!")
        os.system("timeout 1 >nul")
        print(f"   [{R}+{W}] All results will be stored in ports.txt")
        os.system("timeout 1 >nul")
        print(" ")
        again = input(f"   {W}[{R}+{W}] Scan a Different IP ({G}y{W}/{B}n{W}): ")
        print(" ")
        if again.lower() == 'n':
            break
        elif again.lower() == 'y':
            if os.name == 'nt':
                os.system("cls")
            else:
                os.system("clear")
        else:
            print(f"   {W}[{R}+{W}] Invalid choice! Please try again.")

if __name__ == "__main__":
    display_menu()
    scan()
